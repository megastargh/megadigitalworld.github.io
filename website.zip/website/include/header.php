<div class="header-section" style="background-color: rgb(86, 162, 175);">
        <!--menu-right-->
        <div class="top_menu">  
          <!--/profile_details-->
          <div class="profile_details_left">
            <ul class="nofitications-dropdown" style="background-color: rgb(86, 162, 175);">
              <li class="dropdown note dra-down">
              </li>
              <p style="text-align: left; color: white; font-size: 2em;">School Grading</p>
              <p style="text-align: center; color: white; font-size: 1em;">Admin</p>                   
              <div class="clearfix"></div>  
           </ul>
          </div>
          <div class="clearfix"></div>  
          <!--//profile_details-->
        </div>
        <!--//menu-right-->
        <div class="clearfix"></div>
      </div>