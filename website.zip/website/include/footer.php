<footer>
<p style="text-align: center; color: white;">Copyright&copy; School Grading @2022</p>
</footer>