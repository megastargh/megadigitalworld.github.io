<div class="sidebar-menu">
    <!--sidebar menu listered here-->
    <div class="menu">
        <ul id="menu">
            <h3 style="color: #fff; border-bottom: solid 2px; padding-left: 2px; font-size: 2em;">Student Records</h3>
            <li><a href="dashboard.php" title="Dashboard"><i class="fa fa-tachometer"></i><span>Dashboard<span></a></li>

            <li><a  href="student.php" title="Home"><i class="fa fa-users" ></i><span>Students<span></a></li>
            <li><a  href="logout.php" title=""><i class="fa fa-users" ></i><span>Logout<span></a></li>

        </ul>
    </div>
</div>